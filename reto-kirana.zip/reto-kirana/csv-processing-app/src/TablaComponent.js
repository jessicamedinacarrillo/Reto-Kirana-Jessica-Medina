import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const TablaComponent = ({ data }) => {
    return (
        <table>
            <thead>
                <tr>
                    
                </tr>
            </thead>
            <tbody>
                {data.map((persona, index) => (
                <tr key={index}>
                    <td>{persona.nombre}</td>
                    <td>{persona.correo}</td>
                    <td>{persona.telefono}</td>
                </tr>
                ))}
            </tbody>
        </table>
    );
};

export default TablaComponent;
