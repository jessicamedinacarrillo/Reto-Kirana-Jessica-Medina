import React, { useState } from 'react';
import Papa from 'papaparse';
import 'bootstrap/dist/css/bootstrap.min.css';
import validator from 'validator'; // Librería para validar email
import './index.css';


const CsvProcessor = () => {
    // Estados para almacenar los datos del archivo CSV
    const [csvData, setCsvData] = useState([]);
    const [duplicateValuesCount, setDuplicateValuesCount] = useState(0);
    const [totalPersonsCount, setTotalPersonsCount] = useState(0);

    const handleFileChange = (e) => {
        const file = e.target.files[0];

         // Se utilizó la librería PapaParse para analizar el archivo CSV
        Papa.parse(file, {
            complete: (result) => {
                // Elimina las filas duplicadas 
                const uniqueRows = Array.from(new Set(result.data.map(JSON.stringify)), JSON.parse);

                // Resalta los números de teléfono no válidos y cuenta los valores duplicados
                const dataWithInvalidPhones = highlightInvalidPhones('Telefono', uniqueRows);
            
                // Contar valores duplicados
                const seenValues = new Set();
                let duplicateCount = 0;

                dataWithInvalidPhones.forEach((row) => {
                    Object.values(row).forEach((value) => {
                        const valueString = JSON.stringify(value);
                        if (seenValues.has(valueString)) {
                            duplicateCount++;
                        } else {
                            seenValues.add(valueString);
                        }
                    });
                });


                 // Actualiza los estados con la información procesada
                const totalPersons = dataWithInvalidPhones.length;

                setDuplicateValuesCount(duplicateCount);
                setTotalPersonsCount(totalPersons);

                setCsvData(dataWithInvalidPhones);
            },
            header: true,
        });
    };
    
    return (
        <div className=' justify-content-center'>
            <div className='d-flex justify-content-center mb-4'>
                {/* Botón de Subir Archivo */}
                <label className="btn-subir d-flex justify-content-center align-items-center" htmlFor="file-upload">
                    <b>Subir archivo</b>
                    <input
                        id="file-upload"
                        type="file"
                        className="file-input "
                        onChange={handleFileChange}
                        style={{ display: 'none' }}
                    />
                </label>
            </div>

            {/* Muestra la cantidad de valores duplicados si hay alguno */}
            {duplicateValuesCount > 0 && (
                <div className='d-flex' style={{ marginBottom: '10px' }}>
                    Número de valores duplicados: {duplicateValuesCount}
                </div>
            )}

             {/* Muestra el número total de personas en una agenda telefónica */}
            {totalPersonsCount > 0 && (
                <div className='d-flex' style={{ marginBottom: '10px' }}>
                    Número total de personas: {totalPersonsCount}
                </div>
            )}

            {/* Tabla que muestra los datos del archivo CSV */}
            <table className="table custom-table mb-5 ">
                <thead>
                    <tr>
                        {csvData.length > 0 &&
                        Object.keys(csvData[0]).map((header) => (
                            <th key={header}>{header}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {/* Mapea cada fila de datos en la tabla */}
                    {csvData.map((row, index) => (
                        <tr key={index} style={isRowRepeated(row, csvData) || (row.invalidPhone && row.invalidPhone === true)
                            ? { backgroundColor: '#C70039' }
                            : null}>

                            {/* Mapea cada celda de la fila */}
                            {Object.keys(row).map((key, colIndex) => (
                                <td
                                    key={colIndex}  
                                >
                                    {/* Resalta las celdas repetidas o con teléfonos no válidos */}
                                    {isCellRepeated(row, key, csvData) || (key === 'Telefono' && row.invalidPhone)
                                    ? <span style={{ backgroundColor: '#C70039', color:'#fff' }}>{row[key]}</span>
                                    : row[key]}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

// Función para verificar si una fila es repetida
const isRowRepeated = (row, data) => {
        const count = data.filter((r) =>
        Object.keys(r).every((key) => r[key] === row[key])
    ).length;

    return count > 1;
};

// Función para verificar si una celda es repetida en una columna
const isCellRepeated = (row, columnName, data) => {
    const count = data.filter((r) => r[columnName] === row[columnName]).length;
    return count > 1;
};

// Función para pintar teléfonos no válidos y correos electrónicos no válidos
const highlightInvalidPhones = (columnName, data) => {
    return data.map((row) => {
        const telefono = row['Telefono'];
        const isValidTelefono = telefono && telefono.length === 10;

        const correo = row['Correo Electronico'];
        const isValidCorreo = correo && validator.isEmail(correo);

        // Pinta los valores de correo no válido o números telefónicos con más de 10 números de color amarillo
        return {
            ...row,
            'Telefono': isValidTelefono ? telefono : <span style={{ backgroundColor: '#FFF78A' }}>{telefono}</span>,
            'Correo Electronico': isValidCorreo ? correo : <span style={{ backgroundColor: isValidCorreo ? 'transparent' : '#FFF78A' }}>{correo}</span>,
        };
    });
};

export default CsvProcessor;
