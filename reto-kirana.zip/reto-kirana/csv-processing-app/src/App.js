import React, { useState } from 'react';
import CsvProcessor from './CsvProcessor';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';  
import heroImage from './2.png'; 


const App = () => {
  const [data] = useState([]);
  
  return (
    <div>
      {/* Sección Hero */}
      <div className="hero-section px-4 py-5 mb-5 text-center" style={{ backgroundImage: `url(${heroImage})` }}>
        <h1 className="display-5 fw-bold title">El Reto Kirana</h1>
        <div className="col-lg-6 mx-auto">
          <p className="lead mb-4">Bienvenido a mi sitio! Aquí puedes procesar archivos CSV</p>
        </div>
      </div>

      {/* Aquí se añadirá la tabla una vez seleccionado un archivo */}
      <div className="container">      
        <CsvProcessor data={data} />
      </div>
      
      {/* Footer */}
      <footer className="seccion-oscura d-flex flex-column align-items-center justify-content-center"> 
        <p className="footer-texto text-center">Creemos un proyecto juntos.</p>
        <div className="iconos-redes-sociales d-flex flex-wrap align-items-center justify-content-center">
          <a href="https://github.com/jessica815/My_Portfolio/" target="_blank" rel="noopener noreferrer">
            <i className="bi bi-github"></i>
          </a>
          <a href="https://linkedin.com/in/jessicamedinacarrillo" target="_blank" rel="noopener noreferrer">
            <i className="bi bi-linkedin"></i>
          </a>
          <a href="https://www.instagram.com/jessicamonzerrat/" target="_blank" rel="noopener noreferrer">
            <i className="bi bi-instagram"></i>
          </a>
          <a href="mailto:jssmedina09@gmail.com" target="_blank" rel="noopener noreferrer">
            <i className="bi bi-envelope"></i>
          </a>
        </div>
        <div className="derechos-de-autor">Creado por Jessica Monzerrat Medina Carrillo (2024) &#169;</div>
      </footer>
    </div>
  );
};

export default App;
